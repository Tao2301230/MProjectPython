#!/usr/bin/env python
#
# Optimize blocksize of apps/mmm_block.cpp
#
# This is an extremely simplified version meant only for tutorials
#
import adddeps  # fix sys.path

import opentuner
from opentuner import ConfigurationManipulator
from opentuner import IntegerParameter
from opentuner import MeasurementInterface
from opentuner import Result



class GccFlagsTuner(MeasurementInterface):

  def manipulator(self):
    """
    Define the search space by creating a
    ConfigurationManipulator
    """
    manipulator = ConfigurationManipulator()
    manipulator.add_parameter(
      IntegerParameter('BLOCK_SIZE', 1, 3)),
      # BooleanParameter('')
    return manipulator

  def run(self, desired_result, input, limit):
    """
    Compile and run a given configuration then
    return performance
    """
    cfg = desired_result.configuration.data
    # print "cfg: " + cfg
    gcc_cmd = 'g++ mmm_block.cpp '  
    gcc_cmd += ' -D{0}={1}'.format('BLOCK_SIZE',cfg['BLOCK_SIZE'])
    gcc_cmd += ' -o ./tmp.bin'

    print 'gcc: ' + gcc_cmd
    compile_result = self.call_program(gcc_cmd)
    assert compile_result['returncode'] == 0

    run_cmd = './tmp.bin'

    run_result = self.call_program(run_cmd)
    assert run_result['returncode'] == 0

    return Result(time=run_result['time'])

  def save_final_config(self, configuration):
    """called at the end of tuning"""
    print "Optimal block size written to mmm_final_config.json:", configuration.data
    self.manipulator().save_to_file(configuration.data,
                                    'mmm_final_config.json')

'''
if __name__ == '__main__':
  argparser = opentuner.default_argparser()
  print argparser.parse_args()
  GccFlagsTuner.main(argparser.parse_args())
'''

argparser = opentuner.default_argparser()
# print argparser.parse_args()

param =   "--bail_threshold=500 --database=None --display_frequency=10 \
          --generate_bandit_technique=False --label=None --list_techniques=False \
          --machine_class=None --no_dups=False --parallel_compile=False \
          --parallelism=4 --pipelining=0 --print_params=False \
          --print_search_space_size=False --quiet=False --results_log=None \
          --results_log_details=None --seed_configuration=[] --stop_after=None \
          --technique=None --test_limit=5000"

argparser.add_argument(param)
# GccFlagsTuner.main(param)
GccFlagsTuner.main()
