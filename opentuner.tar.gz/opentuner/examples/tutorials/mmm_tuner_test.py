#!/usr/bin/env python
#
# Optimize blocksize of apps/mmm_block.cpp
#
# This is an extremely simplified version meant only for tutorials
#
import adddeps  # fix sys.path

import opentuner
from opentuner import ConfigurationManipulator
from opentuner import IntegerParameter, EnumParameter
from opentuner import MeasurementInterface
from opentuner import Result

gl.spark_parameter = {'early-inlining-insns': ['IntegerParameter', '0-10'],
#             'align-functions': ['EnumParameter', 'on|off|default'],
#             'align-jumps': ['EnumParameter', 'on|off|default'],
             'align-labels': ['EnumParameter', 'on|off|default']}

class GccFlagsTuner(MeasurementInterface):
  def manipulator(self, param, min, max):
    """
    Define the search space by creating a
    ConfigurationManipulator
    """
    manipulator = ConfigurationManipulator()
    manipulator.add_parameter(
      IntegerParameter(param, min, max),
      EnumParameter([['align-labels', 'on'], ['align-labels', 'off'], ['align-labels', 'default']]),
      EnumParameter([['early-inlining-insns', 'on'], ['early-inlining-insns', 'off'], ['early-inlining-insns', 'default']])

    )


    return manipulator


  def run(self, desired_result, input, param, limit):
    """
    Compile and run a given configuration then
    return performance
    """

    cfg = desired_result.configuration.data

    gcc_cmd = 'g++ ' + input
    gcc_cmd += ' -D{0}={1}'.format(param,cfg[param])
    gcc_cmd += ' -f{0}'.format('align-labels')
    gcc_cmd += ' -f{0}'.format('early-inlining-insns')
    gcc_cmd += ' -o ./tmp.bin'

    compile_result = self.call_program(gcc_cmd)
    assert compile_result['returncode'] == 0

    run_cmd = './tmp.bin'

    run_result = self.call_program(run_cmd, limit)
    assert run_result['returncode'] == 0

    return Result(time=run_result['time'])


  def save_final_config(configuration):
    """called at the end of tuning"""
    print "Optimal block size written to mmm_final_config.json:", configuration.data
    self.manipulator().save_to_file(configuration.data,
                                    'mmm_final_config.json')


param = 'BLOCK_SIZE'
min = 1
max = 10
input = "mmm_block.cpp"

